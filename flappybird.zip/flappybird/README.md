## Notes

A remake of the 2013 hit flappy bird in Love2D

## Controls

| Button | Action |
|--|--| 
|A |tap/jump|
|D-pad Up|tap/jump|


